// ==UserScript==
// @name         India Today
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://indiatoday.intoday.in/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
       var styles = ".main-navigation, .fixedsocial, .pathway,.tagstxt, div[class*='storynav'], div[id^='ZZloadFix'], #inarticle_wrapper_div, .nocontent, div[class^='liked'], #banner-section, .OUTBRAIN,.rightpanel,header, #adContent, iframe, .add-left, add-right, .jw-media,.share-social, .top-menu, #fixedMenu, .jw-aspect, .jw-reset, footer, .cnwidget, .cndesktop,  .cnvw, .cnheader-small, .cnAdzerkDiv, a[href*='adz'] { display: none !important; opacity: 0 !important; visibility: none !important; position:absolute !important; left: -999em !important;}";
    styles += "#section .container, .row, .leftpanel, #strwapper, .strleft { width: 100% !important; }";
    jQuery('<style type="text/css" />').append(styles).appendTo(jQuery('body'));
    
    
    // mute 
    $('audio,video').each(function(){     
            $(this).data('muted',true); //Store elements muted by the button.
            $(this).pause(); // or .muted=true to keep playing muted
    });
})();