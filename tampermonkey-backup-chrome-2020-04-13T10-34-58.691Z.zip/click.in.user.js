// ==UserScript==
// @name         click.in
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.click.in/*
// @grant        none
// @require http://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==

(function() {
    'use strict';
    $(document).ready(function() { $('.contentarea tr:nth-child(4)').eq(0).find('table td:first').remove(); });
    var styles = ".clickin-bottomCatBlock, #footer, header, .header, iframe, #afs_container_right, img, .img, a[onclick*='trackEvent'], #spike_wrapper_div, .spike_wrapper_div, .adsbygoogle, #ad_google, .iframe, .footer { display:none; visibility: hidden; position:absolute; left:-999em; top: -999em; }";
    styles += "#clickin-content, #clickin-rightPanelListing { width: 100% !important; }";
    $("<style type='text/css' />").html(styles).appendTo($('body'));
    window.document.title = "Javascript in life";
    // Your code here...
})();