// ==UserScript==
// @name         Facebook Chat head
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.facebook.com/messages/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Remove blue top banner
    document.getElementById('pagelet_bluebar').remove();
    
    // Remove favicon
    var link = document.querySelector("link[rel*='icon']") || document.createElement('link');
    link.type = 'image/x-icon';
    link.rel = 'shortcut icon';
    link.href = 'http://www.stackoverflow.com/favicon.ico';
    document.getElementsByTagName('head')[0].appendChild(link);
    
    // Remove title
    document.title = "Javascript: AngularJS Messaging";
})();