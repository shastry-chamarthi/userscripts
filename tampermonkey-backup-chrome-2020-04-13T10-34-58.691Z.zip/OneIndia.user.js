// ==UserScript==
// @name         OneIndia
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.oneindia.com/*
// @grant        none
// @require http://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...

        //var style = document.createElement('script');
    var styles = "iframe, .header-ad, .logo, *[id*='ad'], div[class*='ad'], .oi-right, .oi-instant, #oi-instant, .right-ad, .cmscontent-right1, .wrap, article ~ div, header, footer, #notification-link, .rightpanel, .vuukle-powerbar, #youtube_promo { display: none !important; opacity: 0 !important; visibility: hidden !important; position:absolute !important; left: -999em !important;}";
    styles += ".leftpanel, .container, #wrapper, .oi-left { width: 100% !important; }";

    jQuery('<style type="text/css" />').append(styles).appendTo($('body'));
})();