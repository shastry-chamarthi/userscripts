// ==UserScript==
// @name         Techcrunch
// @namespace    https://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://techcrunch.com/*
// @require http://code.jquery.com/jquery-1.12.4.min.js
// @grant        none
// ==/UserScript==

(function(jQuery) {
    'use strict';

    // Your code here...
     var styles = " iframe, .nav-bar, .l-sidebar, .r-sidebar,.announcement, .article-extra, #adDiv, .adDiv, .video-promo-carousel, .video-island, .feature-island-container, #carousel-manhattan-homepage, footer, .collapse, .collapse-adjacent, .island, .plain-island, .header-ad, header, .header { display: none !important; opacity: 0 !important; visibility: hidden !important; position:absolute !important; left: -999em !important;}";
    styles += " .main-content { width: 100% !important; }";
    styles += ".l-main { margin-right: 0 !important; }";
    jQuery('<style type="text/css" />').append(styles).appendTo(jQuery('body'));
    
     // Remove favicon
    var link = document.querySelector("link[rel*='icon']") || document.createElement('link');
    link.type = 'image/x-icon';
    link.rel = 'shortcut icon';
    link.href = 'http://www.stackoverflow.com/favicon.ico';
    document.getElementsByTagName('head')[0].appendChild(link);
    
    // Remove title
    document.title = "Javascript:: Internal Tech crunch base";
})(window[Object.keys(window).find((k) => { return k.indexOf('jQuery') != -1;  })]);