// ==UserScript==
// @name         Canada CIC Dashboard
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://onlineservices-servicesenligne.cic.gc.ca/mycic/home
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    setTimeout(() => {
jQuery('form[id*="view_dashboard_"]').slice(0,3).sort(function(a,b) { console.log("items are", a,b); return a.id.indexOf('1') == -1 ? 1: -1 }).map(function(i, form){
    form.target = "_new";
    setTimeout(function(){
       form.submit();
    }, i*5000);
});
    }, 1000);
    // Your code here...
})();