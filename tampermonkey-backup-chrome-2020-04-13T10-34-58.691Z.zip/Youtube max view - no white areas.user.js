// ==UserScript==
// @name         Youtube max view - no white areas
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.youtube.com/*
// @require https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var styles = "ytd-watch-flexy[theater] #player-theater-container.ytd-watch-flexy, ytd-watch-flexy[fullscreen] #player-theater-container.ytd-watch-flexy { height: 100vh; max-height: 100vh; }, .ytd-page-manager, #page-manager.ytd-app { margin-top: 0 !important; }";
    $("<style />").html(styles).appendTo($('body'));
    $('#masthead').slideUp(1000);
    $('body').on('click', function(){
        $('#masthead').slideDown(100).slideUp(10000);
    });
    // Your code here...
})();