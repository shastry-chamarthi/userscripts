// ==UserScript==
// @name         GM Step6
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://localhost:4503/content/game-market/en-us/admin/create-work-order-5.html*
// @match        http://localhost:4503/content/game-market/en-us/admin/keno-create-work-order-6.html*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    $('#startDate').val("06/25/2017");
    $('#endDate').val("06/27/2017");
    $('#startDate').trigger('change');
    $('button.next').click();
    // Your code here...
})();