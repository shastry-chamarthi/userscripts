// ==UserScript==
// @name         Canada CIC Login - Terms n Conditions
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://onlineservices-servicesenligne.cic.gc.ca/mycic/termsAndConditions
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
jQuery('#_continue').click();
    // Your code here...
})();