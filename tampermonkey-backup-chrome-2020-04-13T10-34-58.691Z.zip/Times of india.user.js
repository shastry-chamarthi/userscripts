// ==UserScript==
// @name         Times of india
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://timesofindia.indiatimes.com/*
// @grant        none
// ==/UserScript==

(function(){setTimeout(function() {
    'use strict';

    // Your code here...
    jQuery('.ntfc_popup').remove();
    var styles = " iframe, img[src*='ad'], img[src*='doubleclick'], .streaming_box, #showTopStories, #gaanaplayer, .articlelist_container,.similar-articles, #ajaxcontent, .leftsocial,.sticky, .ntfc_popup, div[class*='popup'], .relatedarticle, #shareInline, #TPMainDiv, .sponsor_block, .show_wdgt, .topcomment, .relatedarticle ~ div, .ntfc_overlay, header, footer, #navigation, .navbdcrumb, .sidebar { display: none !important; opacity: 0 !important; visibility: hidden !important; position:absolute !important; left: -999em !important;}";
    styles += " .main-content { width: 100% !important; }";
    styles += ".bgImg, body { background: none !important; } ";

    jQuery('<style type="text/css" />').append(styles).appendTo(jQuery('body'));
},1000)})();