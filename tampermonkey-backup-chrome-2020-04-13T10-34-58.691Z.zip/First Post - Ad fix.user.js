// ==UserScript==
// @name         First Post - Ad fix
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.firstpost.com/*
// @grant        none
// @require http://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==
 
(function() {
    'use strict';

    // Your code here...
    var styles = "*[id*='ad'], iframe, .panel-top-stories, audio, video, #clickTAG, .fixBtm, .sidebar, .article-meta, #footer, .colombiaWidget, .more-news, #comments-section, .article-tags { display: none !important; opacity: 0 !important; visibility: hidden !important; position:absolute !important; left: -999em !important;}";
     
    jQuery('<style type="text/css" />').append(styles).appendTo(jQuery('body'));
    
    $('a').off('click hover mouseover mouseout mousein keypress keyup');
    $('a').on('click', function() { console.log('prevent click on ', $(this).html()); return false; });
    
})();