// ==UserScript==
// @name         Clean tutorialspoint
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.tutorialspoint.com/*
// @grant        none
// // @require     http://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==

(function($) {
    'use strict';
    var css = "iframe, header, #rightbar, .main .container .col-md-2, .topgooglead, .bottomgooglead, .footer-copyright { width: 0 !important; height: 0 !important; display: none !important; visibility: hidden !important; position !important: fixed; top: -999em !important; left: -999em !important; opacity: 0 !important; }";

    var width = ".middle-col { width: 100% !important; clear: both; display: block; float: none; } ";
    var center = ".sponsered, .sponsered a { text-align: center; width: 100%; padding: 1rem ; color: #ccc; font-size: 0.8rem; }";

    var sponser = "<div class='sponsered'>Author: <a href='tel: +919700072255'> Sathyanarayana Chamarthi </a></div>";
    $('<style />').html(css + width + center).appendTo($(document.body));
    $(document.body).append(sponser);
    // Your code here...
})(jQuery);