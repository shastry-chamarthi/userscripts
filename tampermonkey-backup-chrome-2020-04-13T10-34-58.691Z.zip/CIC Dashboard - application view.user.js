// ==UserScript==
// @name         CIC Dashboard - application view
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://onlineservices-servicesenligne.cic.gc.ca/mycic/dashboard
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
setTimeout(function() { window.close(); window.opener.focus();  }, 10000);

    // Your code here...
})();