// ==UserScript==
// @name         WillowTV
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.pkcast.com/crichd.php*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var wl = window;
    $(document).ready(()=> {
        var a = setInterval(()=> { $('#hdplayer').nextAll('div').hide(); $('iframe, #floatLayer2').hide().remove(); $('#hdplayer video').get(0).play(); $('#hdplayer video').get(0).volume=1; $('#hdplayer video').get(0).muted=false; wl.focus() },200);
        $('#hdplayer').css({
           position:'fixed',
           left:0,
            right: 0,
            top: 0,
            bottom:0
        });
        $('#hdplayer video').get(0).requestFullscreen();
      //  setTimeout(()=> { location.reload()},300000);
    });

    // Your code here...
})();