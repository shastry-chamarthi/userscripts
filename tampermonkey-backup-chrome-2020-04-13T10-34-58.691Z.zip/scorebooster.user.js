// ==UserScript==
// @name         scorebooster
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://ielts.thescorebooster.com/portal/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
     $(document).on('click', '.sections', function(){
         setTimeout(() => {
           $('video').play();
         },1000);
     });
    // Your code here...
})();