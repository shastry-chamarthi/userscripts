// ==UserScript==
// @name         NYC Pokemap - Clear popup
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://nycpokemap.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var stl = "#overlay { clip: rect(0,0,0,0);width: 1px !important; height: 1px !important; position: fixed !important; left: -999em !important; top: -999em !important; right: -888em !important; bottom: -888em !important; visibility: hidden; }";
    $(document.body).append($('<style type="text/css" />').html(stl));
    $('#overlay').remove();
    // Your code here...
})();