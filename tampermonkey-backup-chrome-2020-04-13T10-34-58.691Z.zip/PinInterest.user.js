// ==UserScript==
// @name         PinInterest
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.pinterest.com/*
// @grant        none
// @require http://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var styles = " div[data-test-giftwrap='true'], div[data-test-unauthheader='true'] { display: none !important; opacity: 0 !important; visibility: hidden !important; position:absolute !important; left: -999em !important;}";
     
    jQuery('<style type="text/css" />').append(styles).appendTo(jQuery('body'));
    
})();