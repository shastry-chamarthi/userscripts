// ==UserScript==
// @name         GM Step2a
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://localhost:4503/content/game-market/en-us/admin/keno-create-work-order-1a.html*
// @grant        none
// @require http://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==

(function() {
    'use strict';
    console.log('step2 executed');
    $("#prices").show().val($("#prices option:last").val());
    $('.keno-spots').find('tr:last').find('input:checkbox').eq(0).prop('checked',1);
    $('.btn-primary').click();
    // Your code here...
})();