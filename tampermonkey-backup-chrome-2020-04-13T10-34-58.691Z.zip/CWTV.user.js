// ==UserScript==
// @name         CWTV
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.cwtv.com/shows/charmed/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var $ = jQuery.noConflict();
    $('section#main').css('background-color', '#242424 !important');
    // Your code here...
})();