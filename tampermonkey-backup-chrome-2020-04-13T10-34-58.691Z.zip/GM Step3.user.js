// ==UserScript==
// @name         GM Step3
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://localhost:4503/content/game-market/en-us/admin/create-work-order-2.html*
// @match        http://localhost:4503/content/game-market/en-us/admin/keno-create-work-order-2.html*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    $('input[name^="gameUniqueIds"]').first().attr('checked',true);
   // $('.new-grid').find('input').val('100000');
    $('button.next').click();
    // Your code here...
})();