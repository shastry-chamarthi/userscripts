// ==UserScript==
// @name         IndianExpress
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://indianexpress.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var styles = "#banner-section,.jwplayer,.iz_prompt_containr, .izmiddle-box, .storytags, .related-full, .OUTBRAIN,.rightpanel,header, #adContent, iframe, .add-left, add-right, .jw-media,.share-social, .top-menu, #fixedMenu, .jw-aspect, .jw-reset, footer, .cnwidget, .cndesktop,  .cnvw, .cnheader-small, .cnAdzerkDiv, a[href*='adz'] { display: none !important; opacity: 0 !important; visibility: none !important; position:absolute !important; left: -999em !important;}";
    styles += "#section .container, .row, .leftpanel { width: 100% !important; }";
    jQuery('<style type="text/css" />').append(styles).appendTo(jQuery('body'));
    window.location.hash = 'story_content_parts';
})();