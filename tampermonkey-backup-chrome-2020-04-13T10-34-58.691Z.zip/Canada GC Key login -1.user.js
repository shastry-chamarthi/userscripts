// ==UserScript==
// @name         Canada GC Key login -1
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://clegc-gckey.gc.ca/j/eng/l?ReqID=*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
setTimeout(function() { jQuery('#login').submit(); }, 3000);
    // Your code here...
})();