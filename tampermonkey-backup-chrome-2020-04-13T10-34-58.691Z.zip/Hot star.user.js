// ==UserScript==
// @name         Hot star
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://ca.hotstar.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
setInterval(() => { window.localStorage.clear() },0);

setTimeout(() => { window.location.reload() }, 290000);
    function goFs(){
        setTimeout(()=> {
        var elem = document.getElementsByClassName('video-js');
        if(elem.length > 0){
            elem[0].style.top = 0;
            elem[0].style.left = 0;
            elem[0].style.bottom = 0;
            elem[0].style.right = 0;
            elem[0].style.position = 'fixed';
            elem[0].style.height = 'auto';
            elem[0].style.zIndex = 9999999;
        }
        }, 2000);
        var ht = document.getElementsByTagName('html');
        ht[0].style.overFlow = 'hidden';
    }
    setTimeout(goFs,2000);
    document.getElementsByTagName('body')[0].addEventListener('click keyup', (e)=> { goFs(e); });
    // Your code here...
})();