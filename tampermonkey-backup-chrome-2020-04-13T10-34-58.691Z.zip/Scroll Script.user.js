// ==UserScript==
// @name         Scroll Script
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://polumaint03:8091/dummymail/dummymail.html
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
jQ('.gwt-Tree.gwt-StackLayoutPanelContent').css('overflow', 'auto');
    // Your code here...
})();