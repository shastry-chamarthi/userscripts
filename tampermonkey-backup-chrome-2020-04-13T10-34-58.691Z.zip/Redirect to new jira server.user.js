// ==UserScript==
// @name         Redirect to new jira server
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Just redirect, don't want multiples
// @author       You
// @match        https://rijira.gtk.gtech.com:8443/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
location.replace('https://jira.gtech.com/'+location.pathname);
    // Your code here...
})();