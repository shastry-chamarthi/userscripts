// ==UserScript==
// @name         Eenadu clean slate - updated
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Clean eenadu.net site and read peacefully
// @author       You
// @match        https://*.eenadu.net/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var elem = document.getElementById('body_ad');
    elem = (elem) ? elem.remove() : '';

    //var style = document.createElement('script');

    var styles = " #body_ad, .ad728-top, .socio, [class*='ads_sidebar'], [id*='teaser'], .GoogleActiveViewClass, .ads680-30, .ticker, .ad-block-300, .ad-block-300, .lcol-ad-block, .ytp-thumbnail-overlay, .videoplay,footer, .top-nav ul li:last-child, .innertop, iframe, #body_ad, #right, IFRAME,  div[class*='ad_container']  { display: none !important; opacity: 0 !important; visibility: hidden !important; position:absolute !important; left: -999em !important; height:0 !important;}";
    styles += ".col-left, .col-right, #wrapper, .gridContainer, .home .main_content, .share_image .main_content  { width : 100% !important }";
    styles += ".thumb-description, .article-title-rgt { float: none !important; width: auto !important;  } ";
    styles += ".box-shadow { box-shadow : none !important; }";
    jQuery('<style type="text/css" />').append(styles).appendTo($('body'));
})();