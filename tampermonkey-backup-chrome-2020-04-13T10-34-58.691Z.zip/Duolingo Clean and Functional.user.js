// ==UserScript==
// @name         Duolingo Clean and Functional
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://*.duolingo.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    setTimeout(function(){
      var  jQ = jQuery;
jQ(document).ready(function(){
   jQ('#root > div > div.LFfrA._3MLiB > div > div._2_lzu > div.-X3R5._25sFh > div._2KDjt.qLMvV._3wmue > div._1SeoJ').hide();
   jQ('#root > div > div.LFfrA._3MLiB > div > div._2_lzu > div.-X3R5._25sFh').hide();
   jQ('#root > div > div.LFfrA._3MLiB > div > div._2_lzu > div._2SCNP._1E3L7').hide();
   jQ('#root > div > div.LFfrA._3MLiB > div > div._2_lzu').hide();
   jQ('#root > div > div.LFfrA._3MLiB > div > div._3MT-S > div._2hEQd._1E3L7 > div > div._3ykek > div').hide();
   jQ('#root > div > div.LFfrA._3MLiB > div > div._3MT-S').css('margin','0 !important');
});
    },3000);
    // Your code here...
})();