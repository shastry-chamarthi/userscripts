// ==UserScript==
// @name         Canada CIC Login - Security Questions
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://onlineservices-servicesenligne.cic.gc.ca/mycic/askSecurityQuestion
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
var questions = {
"pet": "nagu",
"friend": "chirravuri",
"wife": "nyayapati",
"learned": "spanish"
};
    // Your code here...
    var submitAnswer = function(){
     console.log('writing answer');
        var question = jQuery('.question-label').find('strong').text().replace(/\"/g,'');
     var keys = Object.keys(questions);
        var answer = "";
        keys.forEach(function(k){
           if(question.toLowerCase().indexOf(k) != -1){
              answer = questions[k];
           }
        });
        if(answer.length){
          jQuery('#answer').val(answer);
          jQuery('#_continue').trigger('click');
        }
    }
    setTimeout(submitAnswer, 1000);
})();