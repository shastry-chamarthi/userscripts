// ==UserScript==
// @name         W3C
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Learn it
// @author       You
// @match        https://www.w3schools.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var styles = "";
    var iframeStyles = "iframe { display: none !important; opacity: 0 !important; visibility: hidden !important; position:absolute !important; left: -999em !important;}";
    var video = " video, .video-js, div[class*='mgbox'], div[class*='MarketGid'],  div[class*='share-icon'], .scroll-paginate,  div[id*='video'], div[id*='taboola'], div[id*='footer'] { display: none !important; opacity: 0 !important; visibility: hidden !important; position:absolute !important; left: -999em !important;} ";

    var eenaduPage = '#aContainer { display: block !important; opacity: 1 !important; visibility: visible !important; position:inherit !important; left: auto !important;} ';
    styles = iframeStyles + video + eenaduPage;
    jQuery('<style type="text/css" />').append(styles).appendTo(jQuery('body'));
    jQuery("video, .video-js,  div[id*='video']").remove();
    // Your code here...
})();