// ==UserScript==
// @name         Cibil Report Open ALL
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://myscore.cibil.com/CreditView/creditreport.page?enterprise=CIBIL
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    $('.flow-section-toggle').on('click', ()=>{
        setTimeout(()=>{ $('#CR-Accounts .tbody .frow.data-row').show().children('.reports-cell').addClass('details-active status-active'); }, 2000);
    });
    // Your code here...
})();