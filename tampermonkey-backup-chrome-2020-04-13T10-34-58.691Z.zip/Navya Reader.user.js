// ==UserScript==
// @name         Navya Reader
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Go to Index page and set Dual page view
// @author       You
// @include      /https:\/\/epaper\.andhrajyothy\.com\/.+[#page]+/
// @grant        none
// ==/UserScript==

(function($) {
    'use strict';
    setTimeout(function(){
        var params = location.hash.split('#page/');
        if(params && params.length == 2) {
            var pageNumber = params[1].split('/');
            if(pageNumber && pageNumber.length ==2 && pageNumber[0] ==1){
                location.hash = "#dual/4/1";
            }
        }
    },500);
    var customStyles = "div[id*='ad'], .adunit,#taboola-below-article-thumbnails-feed,#tbl-next-up-inner, .tbl-next-up-inner, #top-clips-box, .navbar-right{ display:none !important; visibility: hidden; position: fixed; top: -9999em; left: -9999em; opacity: 0 !important; } div.header { position: relative !important; display:block !important;visibility: visible !important; opacity: 0.9 !important; } #nwb {position: fixed; right: 20px; top: 10px; width: 100px; height: 50px; border-radius: 8px; z-index: 99; }";
    var styles = document.createElement('style');
    styles.type= 'text/css';
    styles.innerHTML = customStyles;
    document.body.appendChild(styles);
    $('.zoomin').click();
})(jQuery);