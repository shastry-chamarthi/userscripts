// ==UserScript==
// @name         Andhra Jyothy e-paper
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://epaper.andhrajyothy.com/c/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    setInterval(function() {
        $('#page-right-panel, .container-fluid, .row, #tbl-next-up').hide();
    },5000);
    // Your code here...
})();