// ==UserScript==
// @name         live cricket
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://*.cric7.live/
// @require         http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js
// @grant        none
// ==/UserScript==
// "https://live.cdn.asset.aparat.com/ab254f9c816521910a4b3217c86e7260/eventhls/ec333d032cdae5286ff7df9d6143b5f14.m3u8?s=zu7XZAQgIOLip-zImHIVwA&e=1562776287&ip=187.188.143.241"
(function($) {
    'use strict';
    var styles = "#player_live .fp-player div, #HTML2, #HTML1 .widget-content ~ *, #main, #main ~ *, #HTML1 .widget-content p ~ *, #HTML1 .widget-content p font a { display: none !important; visibility: hidden !important; clip: rect(0px, 0px, 0px, 0px) !important; top: -999em  !important; left: -9999em  !important; width: 0  !important; height: 0  !important; } ";
    styles += "#HTML1 .widget-content iframe2 { position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important; display: table; width: 100%; height: 100%; }";
    $('<style />').html(styles).appendTo($('body'));
    // Your code here...
})($);