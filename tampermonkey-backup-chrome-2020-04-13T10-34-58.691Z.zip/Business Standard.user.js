// ==UserScript==
// @name         Business Standard
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.business-standard.com/*

// @grant        none
// ==/UserScript== 
(function() {
    'use strict';

    // Your code here...
    var styles = "iframe, head, footer, #Banner_bd, #bg, .bg, div[id^='zd_'], div[id^='zz'], .logo-panel, div[class^='add'], div[class*='ad'], .more-stories-pagination, #footer, #moreOnMarkets, .right-box-2, .top-panel, .second-menu-panel, .sticky, .M-S-panel, .main-cont-right, div[class^='banner'] { display: none !important; opacity: 0 !important; visibility: hidden !important; position:absolute !important; left: -999em !important;}";
     
    styles += ".main-cont-left { width:100% !important; }";
    styles += ".topB { border: none !important; margin: 0 !important; border: 0 !important; }";
    jQuery('<style type="text/css" />').append(styles).appendTo(jQuery('body'));
    
})(); 