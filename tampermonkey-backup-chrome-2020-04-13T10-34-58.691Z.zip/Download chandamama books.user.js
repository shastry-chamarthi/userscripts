// ==UserScript==
// @name         Download chandamama books
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://chandamama.in/telugu/
// @grant        none
// ==/UserScript==

(function($j) {
    'use strict';
    var pdfLinks = [];
    var calls = [];
    var links = ["http://chandamama.in/general/telugusview.php?file=/resources/general/From-Chandamama-art-Book.pdf","http://chandamama.in/general/telugusview.php?file=/resources/general/Chandamama-Celebrating-60-Wonderful-Years-Collectors-Edition.pdf","http://chandamama.in/general/telugusview.php?file=/resources/general/Vapa-art-Chandamama-covers-1960-92.pdf","http://chandamama.in/general/specialtelugu.php","http://chandamama.in/telugu/telugu1947.php","http://chandamama.in/telugu/telugu1948.php","http://chandamama.in/telugu/telugu1949.php","http://chandamama.in/telugu/telugu1950.php","http://chandamama.in/telugu/telugu1951.php","http://chandamama.in/telugu/telugu1952.php","http://chandamama.in/telugu/telugu1953.php","http://chandamama.in/telugu/telugu1954.php","http://chandamama.in/telugu/telugu1955.php","http://chandamama.in/telugu/telugu1956.php","http://chandamama.in/telugu/telugu1957.php","http://chandamama.in/telugu/telugu1958.php","http://chandamama.in/telugu/telugu1959.php","http://chandamama.in/telugu/telugu1960.php","http://chandamama.in/telugu/telugu1961.php","http://chandamama.in/telugu/telugu1962.php","http://chandamama.in/telugu/telugu1963.php","http://chandamama.in/telugu/telugu1964.php","http://chandamama.in/telugu/telugu1965.php","http://chandamama.in/telugu/telugu1966.php","http://chandamama.in/telugu/telugu1967.php","http://chandamama.in/telugu/telugu1968.php","http://chandamama.in/telugu/telugu1969.php","http://chandamama.in/telugu/telugu1970.php","http://chandamama.in/telugu/telugu1971.php","http://chandamama.in/telugu/telugu1972.php","http://chandamama.in/telugu/telugu1973.php","http://chandamama.in/telugu/telugu1974.php","http://chandamama.in/telugu/telugu1975.php","http://chandamama.in/telugu/telugu1976.php","http://chandamama.in/telugu/telugu1977.php","http://chandamama.in/telugu/telugu1978.php","http://chandamama.in/telugu/telugu1979.php","http://chandamama.in/telugu/telugu1980.php","http://chandamama.in/telugu/telugu1981.php","http://chandamama.in/telugu/telugu1982.php","http://chandamama.in/telugu/telugu1983.php","http://chandamama.in/telugu/telugu1984.php","http://chandamama.in/telugu/telugu1985.php","http://chandamama.in/telugu/telugu1986.php","http://chandamama.in/telugu/telugu1987.php","http://chandamama.in/telugu/telugu1988.php","http://chandamama.in/telugu/telugu1989.php","http://chandamama.in/telugu/telugu1990.php","http://chandamama.in/telugu/telugu1991.php","http://chandamama.in/telugu/telugu1992.php","http://chandamama.in/telugu/telugu1993.php","http://chandamama.in/telugu/telugu1994.php","http://chandamama.in/telugu/telugu1995.php","http://chandamama.in/telugu/telugu1996.php","http://chandamama.in/telugu/telugu1997.php","http://chandamama.in/telugu/telugu1998.php","http://chandamama.in/telugu/telugu1999.php","http://chandamama.in/telugu/telugu2000.php","http://chandamama.in/telugu/telugu2001.php","http://chandamama.in/telugu/telugu2002.php","http://chandamama.in/telugu/telugu2003.php","http://chandamama.in/telugu/telugu2004.php","http://chandamama.in/telugu/telugu2005.php","http://chandamama.in/telugu/telugu2006.php","http://chandamama.in/telugu/telugu2007.php","http://chandamama.in/telugu/telugu2012.php"];
    /* function grabUrls(){
          $('.portfolio-item a').each(function(i,elem) {
               links.push(elem.href);
           });
         console.log("all links are", JSON.stringify(links));
         alert('copy log');
     }

    function fqurl(partial) {
         return window.location.href + partial;
    }*/
    function isPDF(elem) {
      return !!elem.match(/\.pdf/)
    }
    var cleanUrl = function(link) {
        //http://chandamama.in/general/telugusview.php?file=/resources/general/From-Chandamama-art-Book.pdf"
        var rx2 = /(.*\.in)(?:\/.+=)(.+pdf$)/;
        rx2 = /(.*\.in)(?:\/.+=\/)(.+\.pdf)/;
     return link.replace(rx2,"$1/$2")
    }
    function grabPageLinks(link){
         return  $.get(link).done(function(res){
            var container = $(res).filter(function(){ return $(this).is('div') && $(this).hasClass('article-row-container') });
            var pages = container.find('div.article-row > a');
            var pageLinks = pages.map(function() { return this.href; });
              $j.each(pageLinks,function(i,elem) {
                  // if pdf, download using window.open
                  if(isPDF(elem)){
                      var resourceUrl = cleanUrl(elem);
                      pdfLinks.push(resourceUrl);
                  } else {  console.error("non pdf links found"); }
              });
             console.log("all links are", JSON.stringify(pdfLinks));
             localStorage.setItem("booklinks", JSON.stringify(pdfLinks));
           });
    }
    $j.each(links,function(i,elem) {
       // if pdf, download using window.open
        if(isPDF(elem)){
         var resourceUrl = cleanUrl(elem);
            pdfLinks.push(resourceUrl);
        }
        // else open in iframe, another script will take care of download part
         else {
          calls.push(grabPageLinks(elem));
         }
    });
  $.when(calls).done(function(){
      localStorage.setItem("booklinks", JSON.stringify(pdfLinks));
    console.log("all links are", pdfLinks.join('\r\n'));
         alert('copy log');
  });



    // Your code here...
})(jQuery);