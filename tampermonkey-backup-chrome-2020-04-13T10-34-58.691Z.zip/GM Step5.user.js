// ==UserScript==
// @name         GM Step5
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://localhost:4503/content/game-market/en-us/admin/create-work-order-4.html*
// @match        http://localhost:4503/content/game-market/en-us/admin/keno-create-work-order-5.html*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    $('input[id*="poolSize"]').first().val('100000');
    $('.odds-configure').find('input[type="text"]').each(function(i,elem){ elem.value= 1;  if(i>0) { elem.value = 1+i+(Math.floor(Math.random()*100)); } $(elem).trigger('change'); });
    $('a[class*="calculate"]').click();
    $('button.next').click();
    // Your code here...
})();