// ==UserScript==
// @name         H1 Status check
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://egov.uscis.gov/casestatus/mycasestatus.do
// @grant        none
// ==/UserScript==

(function($) {
    'use strict';
    var num = "WAC1816352386";
    $('.ui-button-text:visible').click();
    $('#receipt_number').val(num);
   // $('#caseStatusSearchBtn').click();
    // Your code here...
})(jQuery);