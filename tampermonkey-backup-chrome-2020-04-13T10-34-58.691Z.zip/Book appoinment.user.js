// ==UserScript==
// @name         Book appoinment
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mexitel.sre.gob.mx/citas.webportal/pages/private/cita/registro/registroCitasPortalExtranjeros.jsf*
// @grant        none
// ==/UserScript==

(function($) {
    'use strict';

    // Your code here...
    $(document).ready(function(){
        var data = [];
        data.sathya = {
           name: "SATHYANARYANA SHASTRY",
           familyname: "CHAMARTHI",
            dob: "13/05/1985",
            phone: "9700072255",
            mobile: "9700072255",
            passport: "K8253735",
        };
        data.tanu = {
           name: "MANISHA",
           familyname: "NYAYAPATI",
            dob: "10/06/1989",
            phone: "9966322205",
            mobile: "9966322205",
            passport: "J8971639",
        };
        data.abhi = {
           name: "Abhinav Karthikeya",
           familyname: "CHAMARTHI",
            dob: "30/05/2018",
            phone: "9700072255",
            mobile: "9700072255",
            passport: "S3378940",
        };

        var selected = data[ prompt("abhi or tanu", "abhi") ];
     function initFill() {
         console.debug('start form fill');
         //given name
         $('#formRegistroCitaExtranjero\\:nombre').val(selected.name);

         // family name
         $('#formRegistroCitaExtranjero\\:ApellidoPat').val(selected.familyname);
         $('#formRegistroCitaExtranjero\\:Apellidos').val(selected.familyname);

         // dob
         $('#formRegistroCitaExtranjero\\:fechaNacimiento_input').val(selected.dob);

         // phone
         $('#formRegistroCitaExtranjero\\:teldomicilio').val(selected.phone);
         // mobile
         $('#formRegistroCitaExtranjero\\:telmovil').val(selected.phone);
         // passport
         $('#formRegistroCitaExtranjero\\:noPasapAnt').val(selected.passport);
console.debug('### stop form fill ###');

     }
      setTimeout(initFill,20000);
    });
})(jQuery);