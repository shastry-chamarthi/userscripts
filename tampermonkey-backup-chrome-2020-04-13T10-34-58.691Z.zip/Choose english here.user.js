// ==UserScript==
// @name         Choose english here
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.cic.gc.ca/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
location.assign("https://www.canada.ca/en/services/immigration-citizenship.html");
    // Your code here...
})();