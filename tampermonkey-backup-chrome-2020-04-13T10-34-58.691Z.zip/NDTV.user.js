// ==UserScript==
// @name         NDTV
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.ndtv.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    
        //var style = document.createElement('script');
    var styles = " .ins_left_lhs, .noti_bgstyle, .noti_wrap, .nhm_main.gnavigation_bg, .new_nextarrow, .ins_clickvideo_expanded, .story_pics img, div[class^='masthead'], iframe, div[id^='div-gpt-ad'], #sticky_navigation_wrapper, .ins_rhscont300, .sticky_footer, div[id^='taboola-below-main'], .trc_related_container, div[class^='footer'], .ins_nextstory, .ins_keyword, .st_sharebar_new, div[class^='newins'], .new_prevarrow  { display: none !important; opacity: 0 !important; visibility: hidden !important; position:absolute !important; left: -999em !important;}";
    styles += ".ins_lftcont640, .ins_left_rhs { width: 100% !important; }";
    
    jQuery('<style type="text/css" />').append(styles).appendTo($('body'));
})();