// ==UserScript==
// @name         Give it a break dude
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  try to take over the world!
// @author       You
// @match        http://*/*
// @grant        none
// @include      *
// @require      http://code.jquery.com/jquery-1.12.4.min.js
// @exclude      https://www.gsmarena.com/*

// ==/UserScript==

(function() {

    function blindMe() {
        console.log("started");
var makemeblind = $('#makemeblind');
    if(makemeblind.length) {
         $(makemeblind).show();
    } else {
     makemeblind = $("<div id='makemeblind'/>");
       $(makemeblind).css({
          position:"fixed",
           top: 0,
           left:0,
           rigth:0,
           bottom:0,
           width:"100%",
           height: "100%",
           background: "#000",
           "z-index": 999999999999,
       }).show().appendTo($('body'));
        $(makemeblind).on('click',function(e){
            document.body.webkitRequestFullscreen();
        });
        //$(makemeblind).trigger('click');
    }
        setTimeout(function() {
            $('#makemeblind').fadeOut(40000);
            $(makemeblind).on('click',function(e){
                document.webkitExitFullscreen();
            });
          //  $(makemeblind).trigger('click');
        }, 1000);
    }
console.log('firstrun now');
    setInterval(blindMe, 15*60*1000);


})();
