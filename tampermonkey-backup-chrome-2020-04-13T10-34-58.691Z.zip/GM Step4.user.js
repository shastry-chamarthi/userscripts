// ==UserScript==
// @name         GM Step4
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://localhost:4503/content/game-market/en-us/admin/create-work-order-3.html*
// @match        http://localhost:4503/content/game-market/en-us/admin/keno-create-work-order-3.html*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    $('button.next').click();
    // Your code here...
})();