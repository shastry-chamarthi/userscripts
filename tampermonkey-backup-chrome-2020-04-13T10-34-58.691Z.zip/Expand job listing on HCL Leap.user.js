// ==UserScript==
// @name         Expand job listing on HCL Leap
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://wf5.myhcl.com/hclleap/*
// @grant        none
// @require http://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==

(function() {
    'use strict';
    $(document).ready(function() { $('.contentarea tr:nth-child(4)').eq(0).find('table td:first').remove(); });
    var styles = "#form1 > table > tbody > tr:nth-child(4) > td > table > tbody > tr > td > table > tbody > tr:nth-child(1) > td > table > tbody > tr > td:nth-child(1) > table > tbody > tr > td > table:nth-child(1) > tbody > tr > td > img, .contentarea > tbody:first-child > tr:first-child > td:first-child > table:first-child, #form1 > table > tbody > tr:nth-child(2) > td > img, #form1 > table > tbody > tr:nth-child(4) > td > table > tbody > tr > td > table > tbody > tr:nth-child(1) > td > table > tbody > tr > td:nth-child(2) > table, .footer { display:none; visibility: hidden; position:absolute; left:-999em; top: -999em; }";
    styles += " #MainContent_grvMyApplication > tbody > tr > td:nth-child(9) { display:block; width: 100% !important; height: 19px; text-overflow: ellipsis; overflow:hidden; } ";
    $("<style type='text/css' />").html(styles).appendTo($('body'));
    window.document.title = "Javascript in life";
    // Your code here...
})();