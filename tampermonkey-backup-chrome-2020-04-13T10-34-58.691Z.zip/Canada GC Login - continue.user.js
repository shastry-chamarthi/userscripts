// ==UserScript==
// @name         Canada GC Login - continue
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://clegc-gckey.gc.ca/j/eng/we?execution=e1s1
// @grant        none
// ==/UserScript==
 var disableButton;
(function() {
    'use strict';
setTimeout(function() {
    disableButton = jQuery.noop;
    jQuery('#continue').click(true);
jQuery('#form').submit(true);
}, 1000);
    // Your code here...
})();