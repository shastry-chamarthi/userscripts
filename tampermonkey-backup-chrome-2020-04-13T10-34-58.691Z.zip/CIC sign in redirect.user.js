// ==UserScript==
// @name         CIC sign in redirect
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.canada.ca/en/immigration-refugees-citizenship/services/application.html
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
location.assign('/en/immigration-refugees-citizenship/services/application/account.html');
    // Your code here...
})();