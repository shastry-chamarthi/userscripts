// ==UserScript==
// @name         Duolingo Words for everyone
// @namespace    elior
// @version      0.1
// @description  Allow entering the words section for each language
// @author       Mallowigi
// @match        https://www.duolingo.com/*
// @grant        none
// ==/UserScript==
(function ($) {
    if (!$) return;

    // add stats on page load
    $(document).ready(function() {
        addWords();
    });

    // add stats on language change
    $(document).ajaxComplete(function(event, request, settings){
        if (settings.url.indexOf("switch_language") > -1) {
            addWords();
        }
    });

    // add stats on URL change
    $(window.location).bind("change", function( objEvent, objData ){
        addWords();
    });


    function addWords () {
        var $topbar = $('.topbar-nav-main');
        var $words = $('<li id="words-nav"></li>');
        var $a = $('<a href="/words">Words</a>');

        $words.append($a);
        if (!$topbar.find('#words-nav').length) {
            $('.topbar-nav-main').append($words);
        }

        // Add current language to the authorized languages
        duo.vocab_languages.push(duo.user.attributes.learning_language);
    }

    // custom URL change handler

})(window.jQuery);

