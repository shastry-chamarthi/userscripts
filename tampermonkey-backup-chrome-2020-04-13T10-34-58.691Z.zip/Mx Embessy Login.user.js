// ==UserScript==
// @name         Mx Embessy Login
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mexitel.sre.gob.mx/citas.webportal/pages/public/login/login.jsf
// @grant        none
// @require      http://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==

(function($) {
    'use strict';
    var cred = [ { uname: "chamarthis@hcl.com", pword: "Abc123" },{ uname: "mahek.n10@gmail.com", pword: "Abc123" }];

    // Enable english
    if(!$('#j_idt80 div div table:first-child > tbody > tr > td:nth-child(5) > a img').hasClass('non-transparent')) {
        $('#j_idt80 div div table:first-child > tbody > tr > td:nth-child(5) > a').click();
    } else {
        var select = 1;
        $(document).ready(function(){
            $('#j_username').val(cred[select].uname);
            $('#j_password').val(cred[select].pword);
            setTimeout(function() { $('#btnLoginII').click();   }, 1000);
        });
    }

    // Login starts

})(jQuery);