// ==UserScript==
// @name         Case receiver
// @namespace    http://spellshield.com/
// @version      0.1
// @description  make your chrome cast it..
// @author       You
// @include      http://*
// @include      https://*
// @grant        none
// @require      https://www.gstatic.com/cast/sdk/libs/receiver/2.0.0/cast_receiver.js

// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.mediaElement = document.getElementById('media');
    window.mediaManager = new cast.receiver.MediaManager(window.mediaElement);
    window.castReceiverManager = cast.receiver.CastReceiverManager.getInstance();
    window.castReceiverManager.start();
})();