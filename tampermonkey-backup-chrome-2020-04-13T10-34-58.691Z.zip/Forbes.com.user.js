// ==UserScript==
// @name         Forbes.com 
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.forbes.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
var styles = " .ad-rail-container, .top-ad-container, .video-player, sidenav, .top-ad-container, video, *[class*='ads'], iframe  { display: none !important; opacity: 0 !important; visibility: hidden !important; position:absolute !important; left: -999em !important;}";
    styles += ".body-container { width : 100% !important; max-width: 99vw !important;}";
    styles += ".thumb-description, .article-title-rgt { float: none !important; width: auto !important; } ";
    styles += ".box-shadow { box-shadow : none !important; }";
    jQuery('<style type="text/css" />').append(styles).appendTo($('body'));
    // Your code here...
})();