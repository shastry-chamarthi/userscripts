// ==UserScript==
// @name         Track WES Post - Sathya OU
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.indiapost.gov.in/_layouts/15/dop.portal.tracking/trackconsignment.aspx
// @match        https://www.indiapost.gov.in/_layouts/15/DOP.Portal.Tracking/TrackConsignment.aspx
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    function trackme(){
        var trackNumber = "EN859410166IN";
        var captchaValue = "";
        document.getElementById('ctl00_PlaceHolderMain_ucNewLegacyControl_txtOrignlPgTranNo').value = trackNumber;

        if(document.getElementById('ctl00_PlaceHolderMain_ucNewLegacyControl_ucCaptcha1_lblCaptcha').innerHTML.indexOf('characters as displayed') != -1){
            captchaValue = document.getElementById('ctl00_PlaceHolderMain_ucNewLegacyControl_ucCaptcha1_divimgcaptcha').children[0].innerHTML;
            document.getElementById('ctl00_PlaceHolderMain_ucNewLegacyControl_ucCaptcha1_txtCaptcha').value = captchaValue;
            document.getElementById('ctl00_PlaceHolderMain_ucNewLegacyControl_btnSearch').click();
        } else if(document.getElementById('ctl00_PlaceHolderMain_ucNewLegacyControl_ucCaptcha1_lblCaptcha').innerHTML.indexOf('Evaluate the Expression') != -1){
            var t = document.getElementById('ctl00_PlaceHolderMain_ucNewLegacyControl_ucCaptcha1_divMathCaptcha').children[0].innerHTML;
            captchaValue = eval(t.replace('=','').replace(/\s/g,''));
            document.getElementById('ctl00_PlaceHolderMain_ucNewLegacyControl_ucCaptcha1_txtCaptcha').value = captchaValue;
            document.getElementById('ctl00_PlaceHolderMain_ucNewLegacyControl_btnSearch').click();
        } else {
            document.getElementById('ctl00_PlaceHolderMain_ucNewLegacyControl_ucCaptcha1_imgbtnCaptcha').click();
            setTimeout(trackme,2000);
        }
    }
    // Your code here...
    trackme();
})();