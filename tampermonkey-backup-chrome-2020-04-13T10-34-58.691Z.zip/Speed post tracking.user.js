// ==UserScript==
// @name         Speed post tracking
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Find my passport!
// @author       You
// @match        https://www.indiapost.gov.in/_layouts/15/DOP.Portal.Tracking/TrackConsignment.aspx
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
$('input:text').eq(1).val("PP425884095IN");
    // Your code here...
})();