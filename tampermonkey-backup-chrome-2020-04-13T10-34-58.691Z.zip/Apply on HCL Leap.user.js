// ==UserScript==
// @name         Apply on HCL Leap
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://wf5.myhcl.com/hclleap/employee/Apply.aspx*
// @grant        none
// @require http://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==

var realConfirm=window.confirm;
window.confirm=function(){
    window.confirm=realConfirm;
    return true;
};
(function() {
    'use strict';
setTimeout(function(){
   $('#MainContent_checkAccept').prop('checked',true);
    $('.proceedbutton').click();

    setTimeout(function(){ window.close(); }, 10000);
},2000);
    // Your code here...
})();