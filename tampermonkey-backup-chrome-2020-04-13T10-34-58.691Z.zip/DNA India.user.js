// ==UserScript==
// @name         DNA India
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.dnaindia.com/bollywood/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
     // Your code here...
    jQuery('.ntfc_popup').remove();
    
    var styles = " iframe, #backgroundPopup,  div[id*='bigad'], div[id^='ZZload'],.comment, div[id*='block-views-also-read-article'], .social-share-list, div[class*='view-next-previous-articles'],  div[class*='Related'], .OUTBRAIN, aside, #border_div, .raltedTopics, #pushSec, .backgroundPopup, .publish_info,  .ntfc_popup, #inlineShare, .inlineShare, #newsWidgetSection, .bottomBar, .appPromotion, .twflw, #defaultCommentForm, #populatecomment, .cmtLinks, #inFocus, #postCmtBox, .shareVertHolderArticle,.panacheSocal,.articleImg, .comment_box, .nextstory, .most_read, .i_portfolio, .i_portfolio ~ div, #topNavFixed + div + div, .related_topics, .sharingBox, #sideBar,#feedbackForm, div[class*='popup'], #topNavFixed, #breakingNews + div + a, .relatedarticle, #shareInline, #TPMainDiv, .sponsor_block, .show_wdgt, .topcomment, .relatedarticle ~ div, .ntfc_overlay, header, footer, #navigation, .navbdcrumb, .sidebar { display: none !important; opacity: 0 !important; visibility: hidden !important; position:absolute !important; left: -999em !important;}";
    styles += " .main-content, .pageContent, section.col-sm-8, .col-sm-8, .container, .article_container, .pageHolder2 { width: 100% !important; } .pageContent article { margin-left: 0px !important } .pageContent{ border:none !important; } .pageHolder { width: 97%; padding: 10px;}  ";
    jQuery('<style type="text/css" />').append(styles).appendTo($('body'));
})();