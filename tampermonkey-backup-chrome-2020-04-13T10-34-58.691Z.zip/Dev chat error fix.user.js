// ==UserScript==
// @name         Dev chat error fix
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://refdevinteractive1.dev.igt.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var showPortalButtonByWorkgroup = $.noop;
})();