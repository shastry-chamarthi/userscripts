// ==UserScript==
// @name         Duolingo ad remover
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Removes ads
// @author       You
// @match        https://www.duolingo.com/*
// @grant        none
// @require      http://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==

(function() {
    'use strict';
    var styles= " div > ins, ins, iframe, div > div > ins, body div> ins,._2KDjt, { display: none !important; }";
    $('<style type="text/css" />').html(styles).appendTo($('body'));
    // Your code here...
    jQuery('span:contains("Follow Duolingo")').parent().parent().remove();
})();