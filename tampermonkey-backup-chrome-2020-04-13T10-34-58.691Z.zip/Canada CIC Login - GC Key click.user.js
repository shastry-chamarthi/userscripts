// ==UserScript==
// @name         Canada CIC Login - GC Key click
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.canada.ca/en/immigration-refugees-citizenship/services/application/account.html
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    location.assign("https://onlineservices-servicesenligne-cic.fjgc-gccf.gc.ca/mycic/gccf?lang=eng&idp=gckey&svc=/mycic/start");
    debugger;
})();