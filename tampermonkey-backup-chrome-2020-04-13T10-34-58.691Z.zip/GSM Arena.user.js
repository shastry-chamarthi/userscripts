// ==UserScript==
// @name         GSM Arena
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Take on ads !!
// @author       You
// @match        https://www.gsmarena.com/*
// @grant        none
// @require      http://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    if(typeof jQuery != "undefined" && jQuery){
        var styles = "";
        var iframeStyles = "iframe { display: none !important; opacity: 0 !important; visibility: hidden !important; position:absolute !important; left: -999em !important;}";
        var video = "#subHeader, #todAdv, #topPromo,.sidebar, video,#footer, #social-connect, .footer, .social-share, .video-js,  div[id*='video'] { display: none !important; opacity: 0 !important; visibility: hidden !important; position:absolute !important; left: -999em !important;} ";

        var eenaduPage = '#aContainer,{ display: block !important; opacity: 1 !important; visibility: visible !important; position:inherit !important; left: auto !important;} ';
        var gsm = 'body, body:before, body:after { background : none !important; }';
        var gsm2 = '.main, .review-header, .specs-list, #outer, #wrapper, .wrapper, #topsearch, #topsearch #topsearch-text { width: 100% !important; }';
        styles = iframeStyles + video + gsm + eenaduPage + gsm2;
        jQuery('<style type="text/css" />').append(styles).appendTo(jQuery('body'));
        jQuery("video, .video-js,  div[id*='video']").remove();
    }
})();