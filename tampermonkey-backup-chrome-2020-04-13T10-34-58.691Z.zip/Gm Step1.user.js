// ==UserScript==
// @name         Gm Step1
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://localhost:4503/content/game-market/en-us/admin/create-work-order-channel.html*
// @match        http://localhost:4503/content/game-market/en-us/admin/keno-create-work-order-channel.html*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    $('input[id*="channels"]').eq(0).attr('checked',true);
    $('button.next').click();
    // Your code here...
})();