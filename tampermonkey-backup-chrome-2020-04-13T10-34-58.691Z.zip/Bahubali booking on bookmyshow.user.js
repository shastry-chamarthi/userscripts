// ==UserScript==
// @name         Bahubali booking on bookmyshow
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Just need 2 tickets!!
// @author       You
// @match        https://in.bookmyshow.com/buytickets/baahubali-2-the-conclusion-hyderabad/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
     var a = ($('#venuelist').find('li').length > 1) ? alert("check now") : setTimeout(function() { window.location.reload(); }, 1000*30);
    // Your code here...
})();